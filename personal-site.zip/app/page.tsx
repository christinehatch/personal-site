export default function Home() {
  return (
    <main className="min-h-screen px-6 py-16">
      <h1 className="text-3xl font-semibold">
        Christine Ryan
      </h1>

      <p className="mt-4 max-w-2xl text-lg text-gray-600">
        Software Engineer focused on building systems that make sense.
      </p>
    </main>
  );
}
