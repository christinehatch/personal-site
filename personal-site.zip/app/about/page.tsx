export default function AboutPage() {
  return (
    <section>
      <h1 className="text-2xl font-semibold">
        About
      </h1>

      <p className="mt-4 text-gray-600">
        How I think about building technology.
      </p>
    </section>
  );
}

